﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace odetofood.Models
{
    public class Review
    {
        public int id{ get; set; }
        public string name { get; set; }
        public int rating { get; set; }        

    }
}